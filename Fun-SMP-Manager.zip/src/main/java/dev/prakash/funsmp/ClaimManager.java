package dev.prakash.funsmp;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class ClaimManager {
    private final FunSMPManagerPlugin plugin;
    private final PermissionService permissionService;
    private final List<ClaimRegion> claimRegions = new ArrayList<>();
    private final File claimFile;

    public ClaimManager(FunSMPManagerPlugin plugin, PermissionService permissionService) {
        this.plugin = plugin;
        this.permissionService = permissionService;
        this.claimFile = new File(plugin.getDataFolder(), "claims.yml");
        load();
    }

    public boolean validateClaim(Player player, Location first, Location second) {
        if (player == null || first == null || second == null || first.getWorld() == null || second.getWorld() == null) {
            return false;
        }
        if (!Objects.equals(first.getWorld(), second.getWorld())) {
            return false;
        }

        int minX = Math.min(first.getBlockX(), second.getBlockX());
        int maxX = Math.max(first.getBlockX(), second.getBlockX());
        int minY = Math.min(first.getBlockY(), second.getBlockY());
        int maxY = Math.max(first.getBlockY(), second.getBlockY());
        int minZ = Math.min(first.getBlockZ(), second.getBlockZ());
        int maxZ = Math.max(first.getBlockZ(), second.getBlockZ());

        int width = maxX - minX + 1;
        int height = maxY - minY + 1;
        int length = maxZ - minZ + 1;

        int minWidth = plugin.getConfig().getInt("claims.minimum-width", 5);
        int minHeight = plugin.getConfig().getInt("claims.minimum-height", 5);
        int minLength = plugin.getConfig().getInt("claims.minimum-length", 5);
        if (width < minWidth || height < minHeight || length < minLength) {
            return false;
        }

        ClaimRegion candidate = new ClaimRegion(player.getUniqueId(), first.getWorld(), minX, minY, minZ, maxX, maxY, maxZ);
        for (ClaimRegion region : claimRegions) {
            if (candidate.overlaps(region)) {
                return false;
            }
        }

        int spawnRadius = plugin.getConfig().getInt("claims.protected-spawn-radius", 32);
        Location spawn = first.getWorld().getSpawnLocation();
        if (spawn.distanceSquared(first) < spawnRadius * spawnRadius || spawn.distanceSquared(second) < spawnRadius * spawnRadius) {
            return false;
        }

        return true;
    }

    public boolean createClaim(Player player, Location first, Location second) {
        if (!permissionService.allowsEconomyAction(player)) {
            return false;
        }
        if (!validateClaim(player, first, second)) {
            return false;
        }

        int minX = Math.min(first.getBlockX(), second.getBlockX());
        int maxX = Math.max(first.getBlockX(), second.getBlockX());
        int minY = Math.min(first.getBlockY(), second.getBlockY());
        int maxY = Math.max(first.getBlockY(), second.getBlockY());
        int minZ = Math.min(first.getBlockZ(), second.getBlockZ());
        int maxZ = Math.max(first.getBlockZ(), second.getBlockZ());

        claimRegions.add(new ClaimRegion(player.getUniqueId(), first.getWorld(), minX, minY, minZ, maxX, maxY, maxZ));
        save();
        player.sendMessage("Claim created successfully.");
        return true;
    }

    public boolean isProtected(Location location) {
        if (location == null || location.getWorld() == null) {
            return false;
        }
        for (ClaimRegion region : claimRegions) {
            if (region.getWorld().equals(location.getWorld()) && region.contains(location.toVector())) {
                return true;
            }
        }
        return false;
    }

    public void load() {
        if (!claimFile.exists()) {
            return;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(claimFile);
        for (String key : config.getKeys(false)) {
            try {
                World world = plugin.getServer().getWorld(config.getString(key + ".world"));
                if (world == null) {
                    continue;
                }
                claimRegions.add(new ClaimRegion(
                    UUID.fromString(config.getString(key + ".ownerId")),
                    world,
                    config.getInt(key + ".minX"),
                    config.getInt(key + ".minY"),
                    config.getInt(key + ".minZ"),
                    config.getInt(key + ".maxX"),
                    config.getInt(key + ".maxY"),
                    config.getInt(key + ".maxZ")
                ));
            } catch (Exception ignored) {
                plugin.getLogger().warning("Ignoring malformed claim entry: " + key);
            }
        }
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        for (int i = 0; i < claimRegions.size(); i++) {
            ClaimRegion region = claimRegions.get(i);
            config.set(i + ".ownerId", region.getOwnerId().toString());
            config.set(i + ".world", region.getWorld().getName());
            config.set(i + ".minX", region.getMinX());
            config.set(i + ".minY", region.getMinY());
            config.set(i + ".minZ", region.getMinZ());
            config.set(i + ".maxX", region.getMaxX());
            config.set(i + ".maxY", region.getMaxY());
            config.set(i + ".maxZ", region.getMaxZ());
        }
        try {
            config.save(claimFile);
        } catch (IOException e) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Could not save claim state", e);
        }
    }
}