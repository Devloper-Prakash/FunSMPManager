package dev.prakash.funsmp;

import org.bukkit.entity.Player;

public class PermissionService {
    public boolean isDeveloper(Player player) {
        return player != null && player.hasPermission("fun.smp.manager.developer");
    }

    public boolean isAdmin(Player player) {
        return player != null && player.hasPermission("fun.smp.manager.admin");
    }

    public boolean isModerator(Player player) {
        return player != null && player.hasPermission("fun.smp.manager.mod");
    }

    public boolean canUseSurvivalFly(Player player) {
        return isDeveloper(player) || isAdmin(player);
    }

    public boolean canCreateEvent(Player player) {
        return isDeveloper(player);
    }

    public boolean canManageClaims(Player player) {
        return isDeveloper(player) || player.hasPermission("fun.smp.manager.claim.manage");
    }

    public boolean allowsEconomyAction(Player player) {
        return player != null && player.hasPermission("fun.smp.manager.member");
    }

    public static Rank defaultRank() {
        return Rank.defaultRank();
    }
}