package dev.prakash.funsmp;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.mindrot.jbcrypt.BCrypt;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerAuthService {
    private final FunSMPManagerPlugin plugin;
    private final File authFile;
    private final Map<UUID, Integer> failedAttempts = new HashMap<>();
    private final Map<UUID, Long> lockUntil = new HashMap<>();

    public PlayerAuthService(FunSMPManagerPlugin plugin) {
        this.plugin = plugin;
        this.authFile = new File(plugin.getDataFolder(), "auth.yml");
        if (!authFile.exists()) {
            save();
        }
    }

    public boolean isRegistered(UUID playerId) {
        if (playerId == null) {
            return false;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(authFile);
        return config.contains("players." + playerId + ".passwordHash");
    }

    public boolean register(UUID playerId, String rawPassword) {
        if (playerId == null || rawPassword == null || rawPassword.isBlank() || isRegistered(playerId)) {
            return false;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(authFile);
        config.set("players." + playerId + ".passwordHash", hashPassword(rawPassword));
        config.set("players." + playerId + ".uid", generateUid(playerId));
        try {
            config.save(authFile);
            return true;
        } catch (IOException e) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Could not save auth data", e);
            return false;
        }
    }

    public boolean verify(UUID playerId, String rawPassword) {
        if (playerId == null || rawPassword == null || rawPassword.isBlank()) {
            return false;
        }
        if (isLocked(playerId)) {
            return false;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(authFile);
        String hash = config.getString("players." + playerId + ".passwordHash");
        if (hash == null || hash.isBlank()) {
            registerFailure(playerId);
            return false;
        }
        boolean success = BCrypt.checkpw(rawPassword, hash);
        if (success) {
            failedAttempts.remove(playerId);
            lockUntil.remove(playerId);
        } else {
            registerFailure(playerId);
        }
        return success;
    }

    public boolean isLocked(UUID playerId) {
        Long until = lockUntil.get(playerId);
        if (until != null && System.currentTimeMillis() < until) {
            return true;
        }
        if (until != null) {
            lockUntil.remove(playerId);
        }
        return false;
    }

    public void registerFailure(UUID playerId) {
        int attempts = failedAttempts.getOrDefault(playerId, 0) + 1;
        failedAttempts.put(playerId, attempts);
        int max = plugin.getConfig().getInt("security.auth.max-attempts", 5);
        if (attempts >= max) {
            long lockMs = plugin.getConfig().getLong("security.auth.lock-duration-seconds", 30L) * 1000L;
            lockUntil.put(playerId, System.currentTimeMillis() + lockMs);
            failedAttempts.put(playerId, 0);
        }
    }

    public String generateUid(UUID playerId) {
        if (playerId == null) {
            return "FUN-UNKNOWN";
        }
        return plugin.getConfig().getString("fun-auth.uid-prefix", "FUN") + "-" + playerId.toString().substring(0, 8).toUpperCase();
    }

    public String getUid(UUID playerId) {
        if (playerId == null) {
            return "FUN-UNKNOWN";
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(authFile);
        return config.getString("players." + playerId + ".uid", generateUid(playerId));
    }

    public static String hashPassword(String rawPassword) {
        return BCrypt.hashpw(rawPassword, BCrypt.gensalt(12));
    }

    public void save() {
        try {
            new YamlConfiguration().save(authFile);
        } catch (IOException e) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Could not initialize auth data", e);
        }
    }
}