package dev.prakash.funsmp;

import org.bukkit.configuration.file.FileConfiguration;

public class TelegramService {
    private final FunSMPManagerPlugin plugin;

    public TelegramService(FunSMPManagerPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isEnabled() {
        FileConfiguration config = plugin.getConfig();
        if (!config.getBoolean("telegram.enabled", false)) {
            return false;
        }
        String token = System.getenv().getOrDefault("FUN_SMP_TELEGRAM_TOKEN", "");
        return !token.isBlank();
    }

    public void send(String message) {
        if (!isEnabled() || message == null || message.isBlank()) {
            return;
        }
        String token = System.getenv().getOrDefault("FUN_SMP_TELEGRAM_TOKEN", "");
        if (token.isBlank()) {
            return;
        }
        plugin.getLogger().info("Telegram notifications enabled but not actively sent in this build.");
    }
}