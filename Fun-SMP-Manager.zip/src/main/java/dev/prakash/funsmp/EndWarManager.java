package dev.prakash.funsmp;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EndWarManager {
    private final FunSMPManagerPlugin plugin;
    private final File storageFile;
    private final List<String> announced = new ArrayList<>();

    public EndWarManager(FunSMPManagerPlugin plugin) {
        this.plugin = plugin;
        this.storageFile = new File(plugin.getDataFolder(), "endwar.yml");
        load();
    }

    public void announceIfDue() {
        if (!plugin.getConfig().getBoolean("endwar.enabled", false)) {
            return;
        }

        long now = System.currentTimeMillis() / 1000L;
        long eventTimeSeconds = now + 172800L;
        long remaining = eventTimeSeconds - now;

        if (remaining <= 172800L && !announced.contains("2d")) {
            Bukkit.broadcastMessage("§cEnd War starts in 2 days.");
            announced.add("2d");
            save();
        }
        if (remaining <= 86400L && !announced.contains("1d")) {
            Bukkit.broadcastMessage("§cEnd War starts in 1 day.");
            announced.add("1d");
            save();
        }
        if (remaining <= 1200L && !announced.contains("20m")) {
            Bukkit.broadcastMessage("§cEnd War starts in 20 minutes.");
            announced.add("20m");
            save();
        }
        if (remaining <= 600L && !announced.contains("10m")) {
            Bukkit.broadcastMessage("§cEnd War starts in 10 minutes.");
            announced.add("10m");
            save();
        }
    }

    public void load() {
        if (!storageFile.exists()) {
            return;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(storageFile);
        announced.clear();
        announced.addAll(config.getStringList("announcements"));
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        config.set("announcements", announced);
        try {
            config.save(storageFile);
        } catch (IOException e) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Could not save End War state", e);
        }
    }
}