package dev.prakash.funsmp;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EconomyManager {
    private final FunSMPManagerPlugin plugin;
    private final Map<UUID, Double> balances = new HashMap<>();
    private final File storageFile;

    public EconomyManager(FunSMPManagerPlugin plugin) {
        this.plugin = plugin;
        this.storageFile = new File(plugin.getDataFolder(), "economy.yml");
        load();
    }

    public double getBalance(UUID playerId) {
        if (playerId == null) {
            return 0.0;
        }
        return balances.getOrDefault(playerId, plugin.getConfig().getDouble("economy.starting-balance", 100.0));
    }

    public boolean deposit(UUID playerId, double amount) {
        if (playerId == null || !isValidAmount(amount)) {
            return false;
        }
        balances.put(playerId, getBalance(playerId) + amount);
        save();
        return true;
    }

    public boolean withdraw(UUID playerId, double amount) {
        if (playerId == null || !isValidAmount(amount)) {
            return false;
        }
        double current = getBalance(playerId);
        if (current < amount) {
            return false;
        }
        balances.put(playerId, current - amount);
        save();
        return true;
    }

    public boolean transfer(UUID from, UUID to, double amount) {
        if (from == null || to == null || !isValidAmount(amount)) {
            return false;
        }
        if (!withdraw(from, amount)) {
            return false;
        }
        deposit(to, amount);
        return true;
    }

    public static boolean isValidAmount(double amount) {
        return Double.isFinite(amount) && amount > 0.0;
    }

    public void load() {
        if (!storageFile.exists()) {
            return;
        }
        FileConfiguration config = YamlConfiguration.loadConfiguration(storageFile);
        for (String key : config.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                balances.put(uuid, config.getDouble(key, plugin.getConfig().getDouble("economy.starting-balance", 100.0)));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Ignoring malformed economy entry: " + key);
            }
        }
    }

    public void save() {
        FileConfiguration config = new YamlConfiguration();
        for (Map.Entry<UUID, Double> entry : balances.entrySet()) {
            config.set(entry.getKey().toString(), entry.getValue());
        }
        try {
            config.save(storageFile);
        } catch (IOException e) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Could not save economy state", e);
        }
    }
}