package dev.prakash.funsmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class StaticChamberManager {
    private final FunSMPManagerPlugin plugin;

    public StaticChamberManager(FunSMPManagerPlugin plugin) {
        this.plugin = plugin;
    }

    public void teleport(Player player) {
        if (player == null) {
            return;
        }
        String worldName = plugin.getConfig().getString("static-chamber.destination.world", "world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            player.sendMessage("Static chamber destination is unavailable.");
            return;
        }
        Location destination = new Location(
            world,
            plugin.getConfig().getDouble("static-chamber.destination.x", 0.5),
            plugin.getConfig().getDouble("static-chamber.destination.y", 64.0),
            plugin.getConfig().getDouble("static-chamber.destination.z", 0.5),
            (float) plugin.getConfig().getDouble("static-chamber.destination.yaw", 180.0),
            (float) plugin.getConfig().getDouble("static-chamber.destination.pitch", 0.0)
        );
        player.teleport(destination);
        player.sendMessage("You have been teleported to the static chamber.");
    }
}