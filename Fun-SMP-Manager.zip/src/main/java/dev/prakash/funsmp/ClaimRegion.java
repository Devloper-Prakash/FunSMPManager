package dev.prakash.funsmp;

import org.bukkit.World;
import org.bukkit.util.Vector;

import java.util.Objects;
import java.util.UUID;

public class ClaimRegion {
    private final UUID ownerId;
    private final World world;
    private final int minX;
    private final int maxX;
    private final int minY;
    private final int maxY;
    private final int minZ;
    private final int maxZ;

    public ClaimRegion(UUID ownerId, World world, int x1, int y1, int z1, int x2, int y2, int z2) {
        this.ownerId = ownerId;
        this.world = world;
        this.minX = Math.min(x1, x2);
        this.maxX = Math.max(x1, x2);
        this.minY = Math.min(y1, y2);
        this.maxY = Math.max(y1, y2);
        this.minZ = Math.min(z1, z2);
        this.maxZ = Math.max(z1, z2);
    }

    public boolean overlaps(ClaimRegion other) {
        if (other == null || !Objects.equals(world, other.world)) {
            return false;
        }
        return minX <= other.maxX && maxX >= other.minX
            && minY <= other.maxY && maxY >= other.minY
            && minZ <= other.maxZ && maxZ >= other.minZ;
    }

    public boolean contains(Vector point) {
        return point != null
            && point.getBlockX() >= minX && point.getBlockX() <= maxX
            && point.getBlockY() >= minY && point.getBlockY() <= maxY
            && point.getBlockZ() >= minZ && point.getBlockZ() <= maxZ;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    public World getWorld() {
        return world;
    }

    public int getMinX() {
        return minX;
    }

    public int getMaxX() {
        return maxX;
    }

    public int getMinY() {
        return minY;
    }

    public int getMaxY() {
        return maxY;
    }

    public int getMinZ() {
        return minZ;
    }

    public int getMaxZ() {
        return maxZ;
    }
}