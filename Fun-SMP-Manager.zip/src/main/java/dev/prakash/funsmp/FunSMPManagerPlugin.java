package dev.prakash.funsmp;

import dev.prakash.funsmp.listeners.ClaimProtectionListener;
import dev.prakash.funsmp.listeners.ClaimSelectionListener;
import dev.prakash.funsmp.listeners.InventoryMenuListener;
import dev.prakash.funsmp.listeners.PlayerSessionListener;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class FunSMPManagerPlugin extends JavaPlugin {
    private PermissionService permissionService;
    private EconomyManager economyManager;
    private PlayerAuthService playerAuthService;
    private ClaimManager claimManager;
    private KitManager kitManager;
    private SeasonManager seasonManager;
    private EndWarManager endWarManager;
    private StaticChamberManager staticChamberManager;
    private MenuManager menuManager;
    private TelegramService telegramService;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        validateConfig();

        permissionService = new PermissionService();
        economyManager = new EconomyManager(this);
        playerAuthService = new PlayerAuthService(this);
        claimManager = new ClaimManager(this, permissionService);
        kitManager = new KitManager(this);
        seasonManager = new SeasonManager(this);
        endWarManager = new EndWarManager(this);
        staticChamberManager = new StaticChamberManager(this);
        menuManager = new MenuManager(this, economyManager, claimManager, kitManager, staticChamberManager);
        telegramService = new TelegramService(this);

        registerCommands();
        registerListeners();

        getLogger().info("Fun SMP Manager enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("Fun SMP Manager disabled.");
    }

    private void validateConfig() {
        if (getConfig().getString("ranks.default", "MEMBER") == null) {
            getConfig().set("ranks.default", "MEMBER");
        }
        if (getConfig().getDouble("economy.starting-balance", 100.0) < 0) {
            getConfig().set("economy.starting-balance", 100.0);
        }
        if (getConfig().getInt("claims.minimum-width", 5) <= 0) {
            getConfig().set("claims.minimum-width", 5);
        }
        if (getConfig().getInt("claims.minimum-length", 5) <= 0) {
            getConfig().set("claims.minimum-length", 5);
        }
        if (getConfig().getInt("claims.minimum-height", 5) <= 0) {
            getConfig().set("claims.minimum-height", 5);
        }
        saveConfig();
    }

    private void registerCommands() {
        getCommand("menu").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            menuManager.openMainMenu(player);
            return true;
        });

        getCommand("balance").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            sender.sendMessage("Balance: " + economyManager.getBalance(player.getUniqueId()) + " coins");
            return true;
        });

        getCommand("register").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            if (args.length != 1) {
                sender.sendMessage("Usage: /register <password>");
                return true;
            }
            if (playerAuthService.isRegistered(player.getUniqueId())) {
                sender.sendMessage("You are already registered.");
                return true;
            }
            if (playerAuthService.register(player.getUniqueId(), args[0])) {
                sender.sendMessage(getConfig().getString("messages.register-success", "Registration successful."));
            } else {
                sender.sendMessage("Registration failed.");
            }
            return true;
        });

        getCommand("login").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            if (args.length != 1) {
                sender.sendMessage("Usage: /login <password>");
                return true;
            }
            if (!playerAuthService.isRegistered(player.getUniqueId())) {
                sender.sendMessage("You are not registered. Use /register <password> first.");
                return true;
            }
            if (playerAuthService.verify(player.getUniqueId(), args[0])) {
                sender.sendMessage(getConfig().getString("messages.login-success", "Authentication successful."));
            } else {
                sender.sendMessage("Authentication failed.");
            }
            return true;
        });

        getCommand("auth").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            sender.sendMessage("Fun UID: " + playerAuthService.getUid(player.getUniqueId()));
            sender.sendMessage("Registered: " + playerAuthService.isRegistered(player.getUniqueId()));
            return true;
        });

        getCommand("claim").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            if (!playerAuthService.isRegistered(player.getUniqueId())) {
                sender.sendMessage(getConfig().getString("messages.player-not-authenticated", "You must authenticate first."));
                return true;
            }
            sender.sendMessage("Use a claim axe to select two corners and then confirm the region.");
            return true;
        });

        getCommand("claimaxe").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            ClaimAxeFactory.giveTo(player);
            return true;
        });

        getCommand("kit").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            if (args.length != 1) {
                sender.sendMessage("Usage: /kit <name>");
                return true;
            }
            if (kitManager.claimKit(player, args[0])) {
                sender.sendMessage("Kit " + args[0] + " claimed.");
            } else {
                sender.sendMessage("Kit claim failed or cooldown active.");
            }
            return true;
        });

        getCommand("season").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            if (!permissionService.canCreateEvent(player)) {
                sender.sendMessage("Developer permission required.");
                return true;
            }
            seasonManager.startLaunchCountdown();
            sender.sendMessage("Season launch countdown started.");
            return true;
        });

        getCommand("endwar").setExecutor((sender, command, label, args) -> {
            sender.sendMessage("End War schedule is configured in config.yml and announcements are handled automatically when enabled.");
            return true;
        });

        getCommand("staticchamber").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command must be used by a player.");
                return true;
            }
            staticChamberManager.teleport(player);
            return true;
        });
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new InventoryMenuListener(menuManager), this);
        getServer().getPluginManager().registerEvents(new PlayerSessionListener(this, playerAuthService, permissionService), this);
        getServer().getPluginManager().registerEvents(new ClaimSelectionListener(claimManager), this);
        getServer().getPluginManager().registerEvents(new ClaimProtectionListener(claimManager), this);
    }

    public PermissionService getPermissionService() {
        return permissionService;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public PlayerAuthService getPlayerAuthService() {
        return playerAuthService;
    }

    public ClaimManager getClaimManager() {
        return claimManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public SeasonManager getSeasonManager() {
        return seasonManager;
    }

    public EndWarManager getEndWarManager() {
        return endWarManager;
    }

    public StaticChamberManager getStaticChamberManager() {
        return staticChamberManager;
    }

    public MenuManager getMenuManager() {
        return menuManager;
    }

    public TelegramService getTelegramService() {
        return telegramService;
    }
}