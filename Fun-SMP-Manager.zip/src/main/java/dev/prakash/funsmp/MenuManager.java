package dev.prakash.funsmp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class MenuManager {
    private final FunSMPManagerPlugin plugin;
    private final EconomyManager economyManager;
    private final ClaimManager claimManager;
    private final KitManager kitManager;
    private final StaticChamberManager staticChamberManager;

    public MenuManager(FunSMPManagerPlugin plugin, EconomyManager economyManager, ClaimManager claimManager,
                      KitManager kitManager, StaticChamberManager staticChamberManager) {
        this.plugin = plugin;
        this.economyManager = economyManager;
        this.claimManager = claimManager;
        this.kitManager = kitManager;
        this.staticChamberManager = staticChamberManager;
    }

    public void openMainMenu(Player player) {
        Inventory menu = Bukkit.createInventory(player, 27, "§8Fun SMP Manager");
        menu.setItem(10, createGuiItem(Material.GOLD_INGOT, "§6Economy & Shop", List.of("Balance: " + economyManager.getBalance(player.getUniqueId()) + " coins")));
        menu.setItem(12, createGuiItem(Material.DIAMOND_PICKAXE, "§bLand Claim", List.of("Create and validate a claim")));
        menu.setItem(14, createGuiItem(Material.CHEST, "§aKits", List.of("Claim or save kits")));
        menu.setItem(16, createGuiItem(Material.END_PORTAL_FRAME, "§dStatic Chamber", List.of("Teleport to the configured chamber")));
        menu.setItem(26, createGuiItem(Material.BARRIER, "§cClose", List.of("Close menu")));
        player.openInventory(menu);
    }

    public void openEconomyMenu(Player player) {
        Inventory menu = Bukkit.createInventory(player, 9, "§8Economy");
        menu.setItem(0, createGuiItem(Material.GOLD_INGOT, "§6Balance", List.of("Current balance: " + economyManager.getBalance(player.getUniqueId()))));
        menu.setItem(8, createGuiItem(Material.BARRIER, "§7Back", List.of("Go back")));
        player.openInventory(menu);
    }

    public void openClaimsMenu(Player player) {
        Inventory menu = Bukkit.createInventory(player, 9, "§8Claims");
        menu.setItem(0, createGuiItem(Material.DIAMOND_AXE, "§bClaim Axe", List.of("Use to select two corners")));
        menu.setItem(4, createGuiItem(Material.GRASS_BLOCK, "§aCreate Claim", List.of("Select a region and confirm")));
        menu.setItem(8, createGuiItem(Material.BARRIER, "§7Back", List.of("Go back")));
        player.openInventory(menu);
    }

    public void openKitsMenu(Player player) {
        Inventory menu = Bukkit.createInventory(player, 9, "§8Kits");
        menu.setItem(0, createGuiItem(Material.CHEST, "§aStarter Kit", List.of(kitManager.getClaimStatus(player, "starter"))));
        menu.setItem(8, createGuiItem(Material.BARRIER, "§7Back", List.of("Go back")));
        player.openInventory(menu);
    }

    public void openStaticChamberMenu(Player player) {
        Inventory menu = Bukkit.createInventory(player, 9, "§8Static Chamber");
        menu.setItem(4, createGuiItem(Material.END_PORTAL_FRAME, "§dUse Static Chamber", List.of("Teleport to the configured chamber")));
        menu.setItem(8, createGuiItem(Material.BARRIER, "§7Back", List.of("Go back")));
        player.openInventory(menu);
    }

    public void handleClick(Player player, org.bukkit.event.inventory.InventoryClickEvent event) {
        if (event.getCurrentItem() == null) {
            return;
        }
        String title = event.getView().getTitle();
        if (title.contains("Fun SMP Manager")) {
            event.setCancelled(true);
            switch (event.getSlot()) {
                case 10 -> openEconomyMenu(player);
                case 12 -> openClaimsMenu(player);
                case 14 -> openKitsMenu(player);
                case 16 -> openStaticChamberMenu(player);
                case 26 -> player.closeInventory();
            }
        } else if (title.contains("Economy")) {
            event.setCancelled(true);
            if (event.getSlot() == 8) {
                openMainMenu(player);
            }
        } else if (title.contains("Claims")) {
            event.setCancelled(true);
            if (event.getSlot() == 0) {
                ClaimAxeFactory.giveTo(player);
            } else if (event.getSlot() == 8) {
                openMainMenu(player);
            }
        } else if (title.contains("Kits")) {
            event.setCancelled(true);
            if (event.getSlot() == 8) {
                openMainMenu(player);
            }
        } else if (title.contains("Static Chamber")) {
            event.setCancelled(true);
            if (event.getSlot() == 4) {
                staticChamberManager.teleport(player);
                player.closeInventory();
            } else if (event.getSlot() == 8) {
                openMainMenu(player);
            }
        }
    }

    private ItemStack createGuiItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }
}