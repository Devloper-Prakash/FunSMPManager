package dev.prakash.funsmp.rank;

import dev.prakash.funsmp.FunSMPManager;
import dev.prakash.funsmp.data.PlayerDataStore;
import java.util.UUID;
import org.bukkit.entity.Player;

public final class RankService {
    private final FunSMPManager plugin;
    private final PlayerDataStore data;
    public RankService(FunSMPManager plugin, PlayerDataStore data) { this.plugin = plugin; this.data = data; }
    public Rank get(UUID id) { return data.rank(id); }
    public boolean isDeveloper(Player player) {
        return get(player.getUniqueId()) == Rank.DEVELOPER && player.hasPermission("funsmp.developer");
    }
    public boolean canFly(Player player) {
        Rank rank = get(player.getUniqueId());
        return (rank == Rank.DEVELOPER || rank == Rank.ADMIN) && player.hasPermission("funsmp.fly");
    }
    public boolean canAdmin(Player player) {
        return player.hasPermission("funsmp.developer") && get(player.getUniqueId()) == Rank.DEVELOPER;
    }
    public void set(UUID id, Rank rank) { data.setRank(id, rank); }
}
