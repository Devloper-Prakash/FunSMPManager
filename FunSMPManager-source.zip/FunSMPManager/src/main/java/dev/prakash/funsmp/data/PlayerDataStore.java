package dev.prakash.funsmp.data;

import dev.prakash.funsmp.FunSMPManager;
import dev.prakash.funsmp.rank.Rank;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

public final class PlayerDataStore {
    private final FunSMPManager plugin;
    private final File file;
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<UUID, Rank> ranks = new HashMap<>();
    private final Map<UUID, String> funUids = new HashMap<>();
    private final Map<UUID, Long> hardcoreDeadlines = new HashMap<>();

    public PlayerDataStore(FunSMPManager plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
    }

    public synchronized void load() throws IOException {
        if (!file.exists()) {
            Files.createDirectories(file.toPath().getParent());
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection players = yaml.getConfigurationSection("players");
        if (players == null) return;
        for (String key : players.getKeys(false)) {
            UUID id;
            try { id = UUID.fromString(key); }
            catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Skipping invalid UUID entry in players.yml: " + key);
                continue;
            }
            ConfigurationSection section = players.getConfigurationSection(key);
            if (section == null) continue;
            double balance = section.getDouble("balance", 0.0);
            if (!Double.isFinite(balance) || balance < 0) {
                plugin.getLogger().warning("Invalid balance for " + id + "; resetting to 0.");
                balance = 0.0;
            }
            balances.put(id, balance);
            ranks.put(id, Rank.parse(section.getString("rank", "MEMBER")));
            String uid = section.getString("fun-uid");
            if (uid != null && !uid.isBlank()) funUids.put(id, uid);
            long deadline = section.getLong("hardcore-deadline", 0L);
            if (deadline > 0) hardcoreDeadlines.put(id, deadline);
        }
    }

    public synchronized void save() throws IOException {
        Files.createDirectories(file.toPath().getParent());
        YamlConfiguration yaml = new YamlConfiguration();
        for (UUID id : unionIds()) {
            String base = "players." + id;
            yaml.set(base + ".balance", balances.getOrDefault(id, 0.0));
            yaml.set(base + ".rank", ranks.getOrDefault(id, Rank.MEMBER).name());
            if (funUids.containsKey(id)) yaml.set(base + ".fun-uid", funUids.get(id));
            if (hardcoreDeadlines.containsKey(id)) yaml.set(base + ".hardcore-deadline", hardcoreDeadlines.get(id));
        }
        yaml.save(file);
    }

    private java.util.Set<UUID> unionIds() {
        java.util.Set<UUID> ids = new java.util.HashSet<>();
        ids.addAll(balances.keySet()); ids.addAll(ranks.keySet());
        ids.addAll(funUids.keySet()); ids.addAll(hardcoreDeadlines.keySet());
        return ids;
    }

    public synchronized double balance(UUID id) {
        return balances.getOrDefault(id, plugin.getConfig().getDouble("economy.starting-balance", 0.0));
    }

    public synchronized void setBalance(UUID id, double amount) { balances.put(id, amount); }
    public synchronized Rank rank(UUID id) { return ranks.getOrDefault(id, Rank.MEMBER); }
    public synchronized void setRank(UUID id, Rank rank) { ranks.put(id, rank); }
    public synchronized String funUid(UUID id) {
        return funUids.computeIfAbsent(id, ignored -> "FUN-" + id.toString().replace("-", "").substring(0, 12).toUpperCase(java.util.Locale.ROOT));
    }
    public synchronized long hardcoreDeadline(UUID id) { return hardcoreDeadlines.getOrDefault(id, 0L); }
    public synchronized void setHardcoreDeadline(UUID id, long deadline) {
        if (deadline <= 0) hardcoreDeadlines.remove(id); else hardcoreDeadlines.put(id, deadline);
    }
}
