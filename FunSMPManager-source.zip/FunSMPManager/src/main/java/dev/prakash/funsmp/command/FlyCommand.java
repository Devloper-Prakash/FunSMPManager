package dev.prakash.funsmp.command;

import dev.prakash.funsmp.FunSMPManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class FlyCommand implements CommandExecutor {
    private final FunSMPManager plugin;
    public FlyCommand(FunSMPManager plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("This command is for players."); return true; }
        if (!plugin.ranks().canFly(player)) {
            player.sendMessage(plugin.message("Survival Fly is restricted to configured DEVELOPER/ADMIN ranks."));
            return true;
        }
        boolean enable = !player.getAllowFlight();
        player.setAllowFlight(enable);
        if (!enable) player.setFlying(false);
        player.sendMessage(plugin.message("Survival Fly " + (enable ? "enabled" : "disabled") + "."));
        return true;
    }
}
