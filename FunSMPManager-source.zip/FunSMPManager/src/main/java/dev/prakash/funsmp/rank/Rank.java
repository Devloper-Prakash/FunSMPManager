package dev.prakash.funsmp.rank;

public enum Rank {
    DEVELOPER, ADMIN, MODERATOR, MEMBER;

    public static Rank parse(String value) {
        if (value == null) return MEMBER;
        try {
            return Rank.valueOf(value.trim().toUpperCase(java.util.Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return MEMBER;
        }
    }
}
