package dev.prakash.funsmp;

import dev.prakash.funsmp.command.AdminCommand;
import dev.prakash.funsmp.command.BalanceCommand;
import dev.prakash.funsmp.command.FlyCommand;
import dev.prakash.funsmp.command.MenuCommand;
import dev.prakash.funsmp.command.PayCommand;
import dev.prakash.funsmp.data.PlayerDataStore;
import dev.prakash.funsmp.economy.EconomyService;
import dev.prakash.funsmp.gui.MenuListener;
import dev.prakash.funsmp.rank.RankService;
import java.io.IOException;
import java.util.Objects;
import java.util.logging.Level;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class FunSMPManager extends JavaPlugin {
    private PlayerDataStore dataStore;
    private EconomyService economy;
    private RankService ranks;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            dataStore = new PlayerDataStore(this);
            dataStore.load();
            ranks = new RankService(this, dataStore);
            economy = new EconomyService(this, dataStore);
            register("menu", new MenuCommand(this));
            register("balance", new BalanceCommand(this));
            register("pay", new PayCommand(this));
            register("funsmp", new AdminCommand(this));
            register("fly", new FlyCommand(this));
            getServer().getPluginManager().registerEvents(new MenuListener(this), this);
            getLogger().info("Fun SMP Manager initialized. Copyright © 2022–2026, Developer Prakash");
        } catch (Exception ex) {
            getLogger().log(Level.SEVERE, "Fun SMP Manager failed to initialize; disabling plugin.", ex);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    private void register(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand command = Objects.requireNonNull(getCommand(name), "Command missing from plugin.yml: " + name);
        command.setExecutor(executor);
    }

    @Override
    public void onDisable() {
        if (dataStore != null) {
            try {
                dataStore.save();
            } catch (IOException ex) {
                getLogger().log(Level.SEVERE, "Could not save player data during shutdown.", ex);
            }
        }
        getLogger().info("Fun SMP Manager stopped.");
    }

    public void reloadPluginConfig() {
        reloadConfig();
    }

    public String message(String message) {
        String prefix = getConfig().getString("settings.prefix", "&8[&bFunSMP&8] &r");
        return color(prefix + message);
    }

    public static String color(String value) {
        return ChatColor.translateAlternateColorCodes('&', value == null ? "" : value);
    }

    public PlayerDataStore dataStore() { return dataStore; }
    public EconomyService economy() { return economy; }
    public RankService ranks() { return ranks; }
}
