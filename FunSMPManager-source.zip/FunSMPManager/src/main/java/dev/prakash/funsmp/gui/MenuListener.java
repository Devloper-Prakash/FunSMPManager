package dev.prakash.funsmp.gui;

import dev.prakash.funsmp.FunSMPManager;
import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class MenuListener implements Listener {
    private static final String TITLE = "§0§lFun SMP Manager";
    private final FunSMPManager plugin;
    public MenuListener(FunSMPManager plugin) { this.plugin = plugin; }

    public static void openMain(FunSMPManager plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        inv.setItem(10, item(Material.GOLD_INGOT, "§6Global Economy", "§7View your global balance"));
        inv.setItem(12, item(Material.GOLDEN_AXE, "§eLand Claim", "§7Claim workflow is not enabled in this build"));
        inv.setItem(14, item(Material.BOOK, "§bKits", "§7Kit management is not enabled in this build"));
        inv.setItem(16, item(Material.NETHER_STAR, "§dServer Features", "§7Use /funsmp help for available commands"));
        player.openInventory(inv);
    }

    private static ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(Arrays.asList(lore));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getRawSlot() < 0 || event.getRawSlot() >= event.getView().getTopInventory().getSize()) return;
        if (event.getRawSlot() == 10) {
            player.sendMessage(plugin.message("Global balance: " + String.format(java.util.Locale.ROOT, "%.2f", plugin.economy().balance(player.getUniqueId()))));
            player.closeInventory();
        } else if (event.getRawSlot() == 12) {
            player.sendMessage(plugin.message("Land claims are not active in this baseline. No items or coins were taken."));
        } else if (event.getRawSlot() == 14) {
            player.sendMessage(plugin.message("Kits are not active in this baseline."));
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (TITLE.equals(event.getView().getTitle())) event.setCancelled(true);
    }
}
