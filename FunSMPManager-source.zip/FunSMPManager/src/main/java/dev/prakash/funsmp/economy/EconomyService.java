package dev.prakash.funsmp.economy;

import dev.prakash.funsmp.FunSMPManager;
import dev.prakash.funsmp.data.PlayerDataStore;
import java.io.IOException;
import java.util.UUID;

public final class EconomyService {
    private final FunSMPManager plugin;
    private final PlayerDataStore data;
    public EconomyService(FunSMPManager plugin, PlayerDataStore data) { this.plugin = plugin; this.data = data; }

    public synchronized double balance(UUID id) { return data.balance(id); }

    public synchronized boolean deposit(UUID id, double amount) {
        if (!validPositive(amount)) return false;
        double current = data.balance(id);
        double next = current + amount;
        if (!Double.isFinite(next) || next < current) return false;
        data.setBalance(id, next);
        return true;
    }

    public synchronized boolean withdraw(UUID id, double amount) {
        if (!validPositive(amount)) return false;
        double current = data.balance(id);
        if (current < amount) return false;
        data.setBalance(id, current - amount);
        return true;
    }

    public synchronized boolean transfer(UUID from, UUID to, double amount) {
        if (from.equals(to) || !validPositive(amount)) return false;
        double sender = data.balance(from);
        double receiver = data.balance(to);
        if (sender < amount || !Double.isFinite(receiver + amount)) return false;
        // Both updates occur under this service lock; persistence is performed at shutdown.
        data.setBalance(from, sender - amount);
        data.setBalance(to, receiver + amount);
        return true;
    }

    private boolean validPositive(double amount) {
        double min = plugin.getConfig().getDouble("economy.minimum-payment", 0.01);
        double max = plugin.getConfig().getDouble("economy.maximum-payment", 1_000_000_000.0);
        return Double.isFinite(amount) && amount >= min && amount <= max;
    }

    public synchronized void saveNow() throws IOException { data.save(); }
}
