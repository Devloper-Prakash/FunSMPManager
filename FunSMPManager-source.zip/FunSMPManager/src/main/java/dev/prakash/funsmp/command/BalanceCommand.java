package dev.prakash.funsmp.command;

import dev.prakash.funsmp.FunSMPManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class BalanceCommand implements CommandExecutor {
    private final FunSMPManager plugin;
    public BalanceCommand(FunSMPManager plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player target;
        if (args.length == 0 && sender instanceof Player p) target = p;
        else if (args.length == 1 && sender.hasPermission("funsmp.admin")) target = Bukkit.getPlayerExact(args[0]);
        else { sender.sendMessage(plugin.message("Usage: /balance [online-player]")); return true; }
        if (target == null) { sender.sendMessage(plugin.message("Player must be online.")); return true; }
        sender.sendMessage(plugin.message(target.getName() + "'s balance: " + String.format(java.util.Locale.ROOT, "%.2f", plugin.economy().balance(target.getUniqueId()))));
        return true;
    }
}
