package dev.prakash.funsmp.command;

import dev.prakash.funsmp.FunSMPManager;
import dev.prakash.funsmp.rank.Rank;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

public final class AdminCommand implements CommandExecutor {
    private final FunSMPManager plugin;
    public AdminCommand(FunSMPManager plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        boolean console = sender instanceof ConsoleCommandSender;
        Player player = sender instanceof Player p ? p : null;
        if (!console && (player == null || !plugin.ranks().canAdmin(player))) {
            sender.sendMessage(plugin.message("Only server console or an explicitly ranked DEVELOPER with funsmp.developer may use this command."));
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(plugin.message("/funsmp reload | rank <online-player> <rank> | money <online-player> <amount>"));
            return true;
        }
        switch (args[0].toLowerCase(java.util.Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadPluginConfig();
                sender.sendMessage(plugin.message("Configuration reloaded."));
            }
            case "rank" -> {
                if (args.length != 3) { sender.sendMessage(plugin.message("Usage: /funsmp rank <online-player> <rank>")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(plugin.message("Target must be online.")); return true; }
                Rank rank;
                try { rank = Rank.valueOf(args[2].toUpperCase(java.util.Locale.ROOT)); }
                catch (IllegalArgumentException ex) { sender.sendMessage(plugin.message("Rank must be DEVELOPER, ADMIN, MODERATOR, or MEMBER.")); return true; }
                if ((rank == Rank.ADMIN || rank == Rank.MODERATOR) &&
                    !plugin.getConfig().getBoolean("settings.enabled-privileged-ranks." + rank.name(), false)) {
                    sender.sendMessage(plugin.message(rank.name() + " rank assignment is disabled in config."));
                    return true;
                }
                plugin.ranks().set(target.getUniqueId(), rank);
                plugin.getLogger().info("AUDIT rank-change actor=" + (player == null ? "CONSOLE" : player.getUniqueId()) + " target=" + target.getUniqueId() + " rank=" + rank.name());
                sender.sendMessage(plugin.message("Assigned " + rank.name() + " to " + target.getName() + "."));
            }
            case "money" -> {
                if (args.length != 3) { sender.sendMessage(plugin.message("Usage: /funsmp money <online-player> <amount>")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(plugin.message("Target must be online.")); return true; }
                try {
                    double amount = Double.parseDouble(args[2]);
                    if (!Double.isFinite(amount) || amount < 0) throw new NumberFormatException();
                    plugin.dataStore().setBalance(target.getUniqueId(), amount);
                    plugin.getLogger().info("AUDIT balance-set actor=" + (player == null ? "CONSOLE" : player.getUniqueId()) + " target=" + target.getUniqueId() + " amount=" + amount);
                    sender.sendMessage(plugin.message("Balance set."));
                } catch (NumberFormatException ex) { sender.sendMessage(plugin.message("Amount must be finite and non-negative.")); }
            }
            default -> sender.sendMessage(plugin.message("Unknown subcommand. Use /funsmp help."));
        }
        return true;
    }
}
