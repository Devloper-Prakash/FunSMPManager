package dev.prakash.funsmp.command;

import dev.prakash.funsmp.FunSMPManager;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class PayCommand implements CommandExecutor {
    private final FunSMPManager plugin;
    public PayCommand(FunSMPManager plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("This command is for players."); return true; }
        if (args.length != 2) { player.sendMessage(plugin.message("Usage: /pay <player> <amount>")); return true; }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) { player.sendMessage(plugin.message("That player must be online.")); return true; }
        final double amount;
        try { amount = Double.parseDouble(args[1]); }
        catch (NumberFormatException ex) { player.sendMessage(plugin.message("Invalid amount.")); return true; }
        if (!Double.isFinite(amount) || amount <= 0) { player.sendMessage(plugin.message("Amount must be positive and finite.")); return true; }
        if (!plugin.economy().transfer(player.getUniqueId(), target.getUniqueId(), amount)) {
            player.sendMessage(plugin.message("Payment failed. Check balance and configured limits."));
            return true;
        }
        player.sendMessage(plugin.message("Paid " + String.format(Locale.ROOT, "%.2f", amount) + " coins to " + target.getName() + "."));
        target.sendMessage(plugin.message("Received " + String.format(Locale.ROOT, "%.2f", amount) + " coins from " + player.getName() + "."));
        try { plugin.economy().saveNow(); }
        catch (java.io.IOException ex) {
            plugin.getLogger().severe("Payment data could not be saved immediately: " + ex.getMessage());
            player.sendMessage(plugin.message("Warning: payment applied in memory but immediate persistence failed. Contact staff."));
        }
        return true;
    }
}
