package dev.prakash.funsmp.command;

import dev.prakash.funsmp.FunSMPManager;
import dev.prakash.funsmp.gui.MenuListener;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MenuCommand implements CommandExecutor {
    private final FunSMPManager plugin;
    public MenuCommand(FunSMPManager plugin) { this.plugin = plugin; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("This command is for players."); return true; }
        MenuListener.openMain(plugin, player);
        return true;
    }
}
