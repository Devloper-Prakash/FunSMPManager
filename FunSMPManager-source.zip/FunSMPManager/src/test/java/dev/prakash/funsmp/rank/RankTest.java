package dev.prakash.funsmp.rank;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class RankTest {
    @Test void memberIsSafeFallback() {
        assertEquals(Rank.MEMBER, Rank.parse(null));
        assertEquals(Rank.MEMBER, Rank.parse("not-a-rank"));
    }
    @Test void onlyFourRanksExist() {
        assertEquals(4, Rank.values().length);
    }
}
