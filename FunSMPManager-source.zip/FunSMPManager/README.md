# Fun SMP Manager

Copyright © 2022–2026, Developer Prakash

This ZIP is a **starter implementation**, not a claim that every feature in the original specification is complete. It contains a real Paper plugin entry point, command registration, a basic GUI, UUID-keyed persistent player records, a global economy baseline, rank checks, and a Gradle build definition. The unfinished systems are explicitly listed below instead of being presented as implemented.

## Target and build

- Build target: Paper API `1.21.4-R0.1-SNAPSHOT`
- Java toolchain: 21
- Build command: `gradle clean test build` (or `./gradlew clean test build` if you add a compatible Gradle wrapper)
- Output: `build/libs/FunSMPManager-0.1.0.jar`

The requested Minecraft `26.3` compatibility was not verified in this environment. Do not install this JAR on a production server until you have built it and tested it against the exact Paper release you run. The `api-version` in `plugin.yml` is set to `1.21`; adjust only after verifying the target API.

## Install

1. Install a Paper server with a compatible Java 21 runtime.
2. Build the project with Gradle.
3. Copy `build/libs/FunSMPManager-0.1.0.jar` into the server's `plugins/` directory.
4. Start the server once to generate `plugins/FunSMPManager/config.yml` and `players.yml`.
5. Stop the server before editing configuration, then restart and inspect the console.

## Current commands

- `/menu` — open the basic menu.
- `/balance` — view your balance.
- `/pay <online-player> <amount>` — transfer coins between online players.
- `/fly` — toggle flight only when both the stored rank and permission permit it.
- `/funsmp help`
- `/funsmp reload`
- `/funsmp rank <online-player> <rank>`
- `/funsmp money <online-player> <amount>`

Important: Bukkit's built-in OP status and other plugins' permissions are separate from this plugin's rank records. This plugin does not grant OP. To bootstrap the first DEVELOPER, an operator must explicitly assign `funsmp.developer` and use a trusted administrative process; this baseline does not provide a secure first-run developer-claim workflow.

## Persistence and security notes

- Player records are UUID-keyed in `plugins/FunSMPManager/players.yml`.
- The economy is global within this plugin's data store and is not season-reset by this baseline.
- Player records are saved on shutdown and after `/pay`; this is **not a transactional database** and cannot guarantee crash-safe atomic economy operations.
- Fun UID is currently a deterministic UUID-derived identifier, not an authentication system.
- No passwords are collected or stored. Fun Auth, password hashing, rate limiting, session enforcement, and offline-mode identity protection are not implemented.
- Offline-mode usernames are not cryptographic identity proof.
- Do not expose `/funsmp` or grant developer permissions to untrusted players.
- The rank checks in code supplement Bukkit permissions; they do not replace server access control.

## Implemented in this baseline

- Paper plugin bootstrap and plugin.yml command/permission declarations.
- Default config generation.
- Four rank enum values and MEMBER fallback.
- UUID-based player records and global balance persistence.
- Basic balance, pay, admin balance-set and rank-set commands.
- Survival fly gate requiring DEVELOPER/ADMIN stored rank plus `funsmp.fly`.
- Main inventory menu with click/drag protection.
- Audit messages for rank and administrative balance changes.
- Basic unit tests for rank parsing.

## Not implemented yet

These requested systems are **not complete**: authenticated Fun UID accounts; claims/Claim Axe selection and purchase; overlap/world protection; shop transactions; auction house; kits and rewards; season scheduler/countdown and world reset controls; End War scheduler and deduplication; Hardcore spectator deadline enforcement; LifeSteal; safe RTP; BedWars arenas; Parkour and PvP practice; Static Chamber authorization/limits; Telegram bot integration; performance sampling and alerts; lag-machine heuristics; anti-cheat checks; Floodgate identity integration; GUI pages for the remaining features; database-backed atomic economy transactions; integration/live-server tests.

Config sections for planned systems are defaults/placeholders only and must not be interpreted as proof those features are implemented.

## Troubleshooting

- If Gradle cannot resolve Paper API, verify network access to the Paper Maven repository and the selected API version.
- If the JAR fails to load, check the server Java version and the full server log.
- If a command is denied, verify both the stored UUID rank and the relevant Bukkit permission.
- Keep a copy of the server data before testing; this baseline is not certified for production economy use.
