rootProject.name = "FunSMPManager"
