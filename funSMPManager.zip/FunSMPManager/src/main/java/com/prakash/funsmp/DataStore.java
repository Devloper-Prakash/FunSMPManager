package com.prakash.funsmp;

import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
import java.sql.*;
import java.util.UUID;
import java.util.logging.Level;

final class DataStore {
    private final JavaPlugin plugin;
    private Connection connection;
    DataStore(JavaPlugin plugin) { this.plugin = plugin; }

    synchronized boolean open() {
        try {
            File dir = plugin.getDataFolder();
            if (!dir.exists() && !dir.mkdirs()) throw new SQLException("Could not create plugin directory");
            connection = DriverManager.getConnection("jdbc:sqlite:" + new File(dir, "funsmp.db").getAbsolutePath());
            try (Statement s = connection.createStatement()) {
                s.executeUpdate("PRAGMA journal_mode=WAL");
                s.executeUpdate("PRAGMA busy_timeout=5000");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS players(uuid TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'MEMBER', coins INTEGER NOT NULL DEFAULT 0)");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY AUTOINCREMENT, time_ms INTEGER NOT NULL, uuid TEXT NOT NULL, player_name TEXT NOT NULL, kind TEXT NOT NULL, details TEXT NOT NULL)");
            }
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Database initialization failed", e);
            return false;
        }
    }

    synchronized void ensurePlayer(UUID id, String name, long startingCoins) {
        try (PreparedStatement p = connection.prepareStatement(
                "INSERT OR IGNORE INTO players(uuid,name,role,coins) VALUES(?,?,'MEMBER',?)")) {
            p.setString(1, id.toString()); p.setString(2, name); p.setLong(3, Math.max(0, startingCoins)); p.executeUpdate();
            try (PreparedStatement u = connection.prepareStatement("UPDATE players SET name=? WHERE uuid=?")) {
                u.setString(1, name); u.setString(2, id.toString()); u.executeUpdate();
            }
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Could not initialize player record", e); }
    }

    synchronized StaffRole role(UUID id) {
        try (PreparedStatement p = connection.prepareStatement("SELECT role FROM players WHERE uuid=?")) {
            p.setString(1, id.toString());
            try (ResultSet r = p.executeQuery()) { if (r.next()) return StaffRole.valueOf(r.getString(1)); }
        } catch (Exception ignored) { }
        return StaffRole.MEMBER;
    }

    synchronized void setRole(UUID id, StaffRole role) {
        try (PreparedStatement p = connection.prepareStatement("UPDATE players SET role=? WHERE uuid=?")) {
            p.setString(1, role.name()); p.setString(2, id.toString()); p.executeUpdate();
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Could not update role", e); }
    }

    synchronized long coins(UUID id) {
        try (PreparedStatement p = connection.prepareStatement("SELECT coins FROM players WHERE uuid=?")) {
            p.setString(1, id.toString());
            try (ResultSet r = p.executeQuery()) { if (r.next()) return r.getLong(1); }
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Balance read failed", e); }
        return 0;
    }

    synchronized void addCoins(UUID id, long amount) {
        try (PreparedStatement p = connection.prepareStatement("UPDATE players SET coins=coins+? WHERE uuid=? AND coins<=?")) {
            p.setLong(1, amount); p.setString(2, id.toString()); p.setLong(3, Long.MAX_VALUE - amount);
            p.executeUpdate();
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Balance update failed", e); }
    }

    synchronized void recordSignal(UUID id, String name, String kind, String details) {
        try (PreparedStatement p = connection.prepareStatement(
                "INSERT INTO signals(time_ms,uuid,player_name,kind,details) VALUES(?,?,?,?,?)")) {
            p.setLong(1, System.currentTimeMillis()); p.setString(2, id.toString());
            p.setString(3, name); p.setString(4, kind); p.setString(5, details); p.executeUpdate();
        } catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Signal storage failed", e); }
    }

    synchronized long signalCount() {
        try (Statement s = connection.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(*) FROM signals")) {
            return r.next() ? r.getLong(1) : 0;
        } catch (SQLException e) { return -1; }
    }
    synchronized String recentSignals(int limit) {
        StringBuilder out = new StringBuilder();
        try (PreparedStatement p = connection.prepareStatement(
                "SELECT player_name,kind,time_ms FROM signals ORDER BY id DESC LIMIT ?")) {
            p.setInt(1, limit);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    if (out.length() > 0) out.append(" | ");
                    out.append(r.getString(1)).append(':').append(r.getString(2))
                       .append('@').append(r.getLong(3));
                }
            }
        } catch (SQLException e) { return "unavailable"; }
        return out.length() == 0 ? "none" : out.toString();
    }

    synchronized void close() {
        try { if (connection != null && !connection.isClosed()) connection.close(); }
        catch (SQLException e) { plugin.getLogger().log(Level.WARNING, "Database close failed", e); }
    }
}
