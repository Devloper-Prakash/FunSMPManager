package com.prakash.funsmp;

import org.bukkit.Bukkit;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;

final class TelegramService {
    private final FunSMPManager plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    TelegramService(FunSMPManager plugin) { this.plugin = plugin; }
    void reload() { }

    void playerEvent(String message) {
        if (plugin.getConfig().getBoolean("telegram.send-player-events", false)) sendAll(message);
    }
    void securityEvent(String message) {
        if (plugin.getConfig().getBoolean("telegram.send-security-alerts", true)) sendAll(message);
    }

    private void sendAll(String message) {
        if (!plugin.getConfig().getBoolean("telegram.enabled", true)) return;
        String token = System.getenv(plugin.getConfig().getString("telegram.token-env", "FUN_SMP_TELEGRAM_TOKEN"));
        List<String> ids = plugin.getConfig().getStringList("telegram.allowed-chat-ids");
        if (token == null || token.isBlank() || ids.isEmpty()) return;
        for (String id : ids) {
            String body = "chat_id=" + enc(id) + "&text=" + enc(message);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.telegram.org/bot" + token + "/sendMessage"))
                    .timeout(Duration.ofSeconds(8))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    HttpResponse<Void> response = http.send(request, HttpResponse.BodyHandlers.discarding());
                    if (response.statusCode() / 100 != 2)
                        plugin.getLogger().warning("Telegram notification failed; HTTP " + response.statusCode());
                } catch (Exception ex) { plugin.getLogger().warning("Telegram notification failed: " + ex.getClass().getSimpleName()); }
            });
        }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
