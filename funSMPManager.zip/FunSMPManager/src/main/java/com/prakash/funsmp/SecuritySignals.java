package com.prakash.funsmp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

final class SecuritySignals {
    private final FunSMPManager plugin;
    SecuritySignals(FunSMPManager plugin) { this.plugin = plugin; }

    void signal(Player player, String kind, String details) {
        plugin.store().recordSignal(player.getUniqueId(), player.getName(), kind, details);
        plugin.getLogger().warning("[SECURITY SIGNAL - REVIEW ONLY] " + player.getName() + " " + kind + " " + details);
        if (plugin.staffAlertsEnabled()) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                // Prioritize moderator, then admin, then developer; signal is advisory only.
                StaffRole chosen = onlineRole(StaffRole.MODERATOR);
                if (chosen == null) chosen = onlineRole(StaffRole.ADMIN);
                if (chosen == null) chosen = onlineRole(StaffRole.DEVELOPER);
                if (chosen != null) {
                    for (Player staff : Bukkit.getOnlinePlayers()) {
                        if (plugin.store().role(staff.getUniqueId()) == chosen) {
                            staff.sendMessage(FunSMPManager.color("&6[Review] &e" + player.getName()
                                    + " &7signal=&f" + kind + " &8(details in console)"));
                        }
                    }
                } else {
                    plugin.telegram().securityEvent("Security review signal: " + player.getName() + " / " + kind);
                }
            });
        }
    }

    private StaffRole onlineRole(StaffRole role) {
        for (Player p : Bukkit.getOnlinePlayers())
            if (plugin.store().role(p.getUniqueId()) == role) return role;
        return null;
    }
}
