package com.prakash.funsmp;

public enum StaffRole {
    DEVELOPER, ADMIN, MODERATOR, MEMBER
}
