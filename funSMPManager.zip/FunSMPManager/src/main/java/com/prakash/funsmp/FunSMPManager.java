package com.prakash.funsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class FunSMPManager extends JavaPlugin implements Listener, CommandExecutor {
    private DataStore data;
    private TelegramService telegram;
    private SecuritySignals security;
    private final Map<UUID, Long> lastMoveSignal = new ConcurrentHashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        saveResourceIfMissing("messages.yml");
        data = new DataStore(this);
        if (!data.open()) {
            getLogger().severe("Data store could not initialize. Disabling safely.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        telegram = new TelegramService(this);
        security = new SecuritySignals(this);
        Objects.requireNonNull(getCommand("funsmp")).setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("Fun SMP Manager core enabled. No automatic punishments are active.");
    }

    @Override public void onDisable() {
        if (data != null) data.close();
    }

    private void saveResourceIfMissing(String name) {
        if (!new java.io.File(getDataFolder(), name).exists()) saveResource(name, false);
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        data.ensurePlayer(p.getUniqueId(), p.getName(), getConfig().getLong("economy.starting-coins", 0));
        telegram.playerEvent("Player joined: " + p.getName());
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        telegram.playerEvent("Player left: " + event.getPlayer().getName());
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onMove(PlayerMoveEvent e) {
        if (!getConfig().getBoolean("security.enabled", true)) return;
        if (e.getTo() == null || e.getFrom().getWorld() != e.getTo().getWorld()) return;
        if (e.getFrom().getY() == e.getTo().getY()) return;
        Player p = e.getPlayer();
        // Deliberately conservative advisory heuristic; exemptions/latency make this non-evidence.
        if (p.isFlying() || p.isGliding() || p.isInsideVehicle() || p.hasPermission("funsmp.developer")) return;
        long now = System.currentTimeMillis();
        long cooldown = getConfig().getLong("security.signal-cooldown-seconds", 45) * 1000L;
        if (now - lastMoveSignal.getOrDefault(p.getUniqueId(), 0L) < cooldown) return;
        double dy = e.getTo().getY() - e.getFrom().getY();
        double threshold = getConfig().getDouble("security.suspicious-movement-threshold", 1.35);
        if (dy > threshold && p.getVelocity().getY() < 0.05) {
            lastMoveSignal.put(p.getUniqueId(), now);
            security.signal(p, "UNUSUAL_VERTICAL_MOVEMENT",
                    String.format(Locale.ROOT, "verticalDelta=%.2f; world=%s", dy, p.getWorld().getName()));
        }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(color("&bFun SMP Manager &7v" + getDescription().getVersion()));
            sender.sendMessage(color("&7Online: &f" + Bukkit.getOnlinePlayers().size()
                    + "&7/&f" + Bukkit.getMaxPlayers()));
            sender.sendMessage(color("&7Security signals: &f" + data.signalCount()));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                if (!isDeveloper(sender)) return deny(sender);
                reloadConfig();
                telegram.reload();
                sender.sendMessage(color("&aConfig reloaded."));
            }
            case "rank" -> {
                if (!isDeveloper(sender)) return deny(sender);
                if (args.length != 3) { sender.sendMessage("/funsmp rank <player> <DEVELOPER|ADMIN|MODERATOR|MEMBER>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(color("&cTarget must be online in this initial core.")); return true; }
                StaffRole role;
                try { role = StaffRole.valueOf(args[2].toUpperCase(Locale.ROOT)); }
                catch (IllegalArgumentException ex) { sender.sendMessage(color("&cUnknown role.")); return true; }
                if (role == StaffRole.DEVELOPER && !senderIsConsole(sender)) {
                    sender.sendMessage(color("&cOnly console can assign Developer in this initial release.")); return true;
                }
                data.setRole(target.getUniqueId(), role);
                target.sendMessage(color("&eYour Fun SMP role is now &b" + role + "&e."));
                sender.sendMessage(color("&aRole updated for " + target.getName() + "."));
            }
            case "coins" -> {
                if (!isDeveloper(sender)) return deny(sender);
                if (args.length != 3) { sender.sendMessage("/funsmp coins <online-player> <amount>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(color("&cTarget must be online.")); return true; }
                try {
                    long amount = Long.parseLong(args[2]);
                    if (amount < 0) throw new NumberFormatException();
                    data.addCoins(target.getUniqueId(), amount);
                    sender.sendMessage(color("&aCoins granted. New balance: " + data.coins(target.getUniqueId())));
                } catch (NumberFormatException ex) { sender.sendMessage(color("&cAmount must be a non-negative whole number.")); }
            }
            case "alerts" -> {
                if (!hasRole(sender, StaffRole.MODERATOR) && !isDeveloper(sender)) return deny(sender);
                sender.sendMessage(color("&bRecent security signals: &f" + data.recentSignals(10)));
            }
            default -> sender.sendMessage(color("&e/funsmp <status|reload|rank|coins|alerts>"));
        }
        return true;
    }

    boolean isDeveloper(CommandSender s) {
        if (senderIsConsole(s)) return true;
        if (!(s instanceof Player p)) return false;
        return data.role(p.getUniqueId()) == StaffRole.DEVELOPER;
    }
    boolean hasRole(CommandSender s, StaffRole role) {
        if (!(s instanceof Player p)) return false;
        StaffRole r = data.role(p.getUniqueId());
        return r == StaffRole.DEVELOPER || r == StaffRole.ADMIN || (role == StaffRole.MODERATOR && r == StaffRole.MODERATOR);
    }
    private boolean senderIsConsole(CommandSender s) { return !(s instanceof Player); }
    private boolean deny(CommandSender s) { s.sendMessage(color("&cDeveloper permission required.")); return true; }
    static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    DataStore store() { return data; }
    TelegramService telegram() { return telegram; }
    boolean staffAlertsEnabled() { return getConfig().getBoolean("security.notify-online-staff", true); }
}
